from flask import Blueprint, request, jsonify, session
from user import db, User
from tarefa import Tarefa
from tarefa_execucao import TarefaExecucao

admin_bp = Blueprint('admin', __name__)

def require_admin():
    """Verificar se o usuário é admin"""
    if 'user_id' not in session:
        return jsonify({'error': 'Não autenticado'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.is_admin:
        return jsonify({'error': 'Acesso negado'}), 403
    
    return None

def require_gm():
    """Verificar se o usuário é G.M. ou admin"""
    if 'user_id' not in session:
        return jsonify({'error': 'Não autenticado'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not (user.is_gm or user.is_admin):
        return jsonify({'error': 'Acesso negado'}), 403
    
    return None

# ===== GERENCIAMENTO DE USUÁRIOS =====

@admin_bp.route('/users', methods=['GET'])
def get_users():
    auth_check = require_admin()
    if auth_check:
        return auth_check
    
    try:
        users = User.query.all()
        return jsonify({'users': [user.to_dict() for user in users]}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users/<int:user_id>/update-grau', methods=['POST'])
def update_user_grau(user_id):
    auth_check = require_admin()
    if auth_check:
        return auth_check
    
    try:
        data = request.get_json()
        novo_grau = data.get('grau')
        
        graus_validos = ['Iniciante', 'Iniciado', 'Adepto', 'Aprendiz', 'Discípulo', 'Mago']
        if novo_grau not in graus_validos:
            return jsonify({'error': 'Grau inválido'}), 400
        
        user = User.query.get_or_404(user_id)
        user.grau = novo_grau
        db.session.commit()
        
        return jsonify({'message': f'Grau alterado para {novo_grau}', 'user': user.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users/<int:user_id>/update-pontos', methods=['POST'])
def update_user_pontos(user_id):
    auth_check = require_admin()
    if auth_check:
        return auth_check
    
    try:
        data = request.get_json()
        novos_pontos = data.get('pontos')
        
        if not isinstance(novos_pontos, int) or novos_pontos < 0:
            return jsonify({'error': 'Pontos devem ser um número inteiro positivo'}), 400
        
        user = User.query.get_or_404(user_id)
        user.pontos = novos_pontos
        db.session.commit()
        
        return jsonify({'message': f'Pontos alterados para {novos_pontos}', 'user': user.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# ===== GERENCIAMENTO DE TAREFAS =====

@admin_bp.route('/tarefas', methods=['GET'])
def get_tarefas():
    auth_check = require_gm()
    if auth_check:
        return auth_check
    
    try:
        tarefas = Tarefa.query.all()
        return jsonify({'tarefas': [tarefa.to_dict() for tarefa in tarefas]}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/tarefas', methods=['POST'])
def create_tarefa():
    auth_check = require_gm()
    if auth_check:
        return auth_check
    
    try:
        data = request.get_json()
        
        tarefa = Tarefa(
            titulo=data.get('titulo'),
            descricao=data.get('descricao'),
            grau_minimo=data.get('grau_minimo', 'Iniciante'),
            pontos_recompensa=data.get('pontos_recompensa', 1),
            criado_por=session['user_id'],
            ativa=data.get('ativa', True)
        )
        
        db.session.add(tarefa)
        db.session.commit()
        
        return jsonify({'message': 'Tarefa criada com sucesso', 'tarefa': tarefa.to_dict()}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/tarefas/<int:tarefa_id>', methods=['PUT'])
def update_tarefa(tarefa_id):
    auth_check = require_gm()
    if auth_check:
        return auth_check
    
    try:
        data = request.get_json()
        tarefa = Tarefa.query.get_or_404(tarefa_id)
        
        tarefa.titulo = data.get('titulo', tarefa.titulo)
        tarefa.descricao = data.get('descricao', tarefa.descricao)
        tarefa.grau_minimo = data.get('grau_minimo', tarefa.grau_minimo)
        tarefa.pontos_recompensa = data.get('pontos_recompensa', tarefa.pontos_recompensa)
        tarefa.ativa = data.get('ativa', tarefa.ativa)
        
        db.session.commit()
        
        return jsonify({'message': 'Tarefa atualizada com sucesso', 'tarefa': tarefa.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/tarefas/<int:tarefa_id>', methods=['DELETE'])
def delete_tarefa(tarefa_id):
    auth_check = require_admin()
    if auth_check:
        return auth_check
    
    try:
        tarefa = Tarefa.query.get_or_404(tarefa_id)
        db.session.delete(tarefa)
        db.session.commit()
        
        return jsonify({'message': 'Tarefa removida com sucesso'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

