import os
from flask import Flask, render_template, send_from_directory
from flask_cors import CORS

# Import models and blueprints
from user import db, User
from tarefa import Tarefa
from tarefa_execucao import TarefaExecucao
from biblioteca import BibliotecaItem
from mensagem import Mensagem
from forum import ForumPost
from comprovante_pagamento import ComprovantePagamento

# Import blueprints
from auth import auth_bp
from admin import admin_bp
from user import user_bp
from biblioteca import biblioteca_bp
from mensagem import mensagem_bp
from forum import forum_bp
from comprovante_pagamento import comprovante_bp

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = 'sua_chave_secreta_muito_segura_aqui_2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('database', exist_ok=True)

# Initialize extensions
db.init_app(app)
CORS(app, supports_credentials=True)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(admin_bp, url_prefix='/api/admin')
app.register_blueprint(user_bp, url_prefix='/api/user')
app.register_blueprint(biblioteca_bp, url_prefix='/api/biblioteca')
app.register_blueprint(mensagem_bp, url_prefix='/api/mensagens')
app.register_blueprint(forum_bp, url_prefix='/api/forum')
app.register_blueprint(comprovante_bp, url_prefix='/api/comprovante')

# Routes for serving static files
@app.route('/')
def index():
    return '''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Mágico Sagrado</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            color: #ffffff;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        .header {
            background: rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }

        .logo {
            display: flex;
            align-items: center;
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo i {
            margin-right: 0.5rem;
            color: #ffd700;
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2rem;
        }

        .nav-links a {
            color: #ffffff;
            text-decoration: none;
            transition: all 0.3s ease;
            padding: 0.5rem 1rem;
            border-radius: 25px;
        }

        .nav-links a:hover {
            background: rgba(255, 215, 0, 0.2);
            color: #ffd700;
        }

        /* Hero Section */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            position: relative;
            padding-top: 80px;
        }

        .hero-content h1 {
            font-size: 4rem;
            margin-bottom: 1rem;
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: glow 2s ease-in-out infinite alternate;
        }

        @keyframes glow {
            from { text-shadow: 0 0 20px rgba(255, 215, 0, 0.5); }
            to { text-shadow: 0 0 30px rgba(255, 215, 0, 0.8); }
        }

        .hero-content p {
            font-size: 1.5rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }

        .cta-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 1rem 2rem;
            border: none;
            border-radius: 50px;
            font-size: 1.1rem;
            font-weight: bold;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            color: #1a1a2e;
        }

        .btn-secondary {
            background: transparent;
            color: #ffffff;
            border: 2px solid #ffd700;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(255, 215, 0, 0.3);
        }

        /* Sections */
        .section {
            padding: 5rem 0;
        }

        .section h2 {
            font-size: 3rem;
            text-align: center;
            margin-bottom: 3rem;
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(255, 215, 0, 0.2);
        }

        .feature-card i {
            font-size: 3rem;
            color: #ffd700;
            margin-bottom: 1rem;
        }

        .feature-card h3 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: #ffed4e;
        }

        /* Login Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            margin: 5% auto;
            padding: 2rem;
            border-radius: 20px;
            width: 90%;
            max-width: 400px;
            border: 1px solid rgba(255, 215, 0, 0.3);
            position: relative;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            position: absolute;
            top: 1rem;
            right: 1.5rem;
        }

        .close:hover {
            color: #ffd700;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #ffd700;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 1rem;
            border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            font-size: 1rem;
        }

        .form-group input:focus {
            outline: none;
            border-color: #ffd700;
            box-shadow: 0 0 10px rgba(255, 215, 0, 0.3);
        }

        .form-tabs {
            display: flex;
            margin-bottom: 2rem;
            border-radius: 10px;
            overflow: hidden;
        }

        .tab-btn {
            flex: 1;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: #ffffff;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .tab-btn.active {
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            color: #1a1a2e;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero-content h1 {
                font-size: 2.5rem;
            }

            .nav-links {
                display: none;
            }

            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }
        }

        /* Footer */
        .footer {
            background: rgba(0, 0, 0, 0.5);
            text-align: center;
            padding: 2rem 0;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer p {
            color: #cccccc;
        }

        .footer a {
            color: #ffd700;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="nav container">
            <div class="logo">
                <i class="fas fa-magic"></i>
                Sistema Mágico Sagrado
            </div>
            <ul class="nav-links">
                <li><a href="#sobre">Sobre Nós</a></li>
                <li><a href="#biblioteca">Biblioteca</a></li>
                <li><a href="#contato">Contato</a></li>
                <li><a href="#" onclick="openModal()">Entrar</a></li>
            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Sistema Mágico Sagrado</h1>
            <p>Desperte seu poder interior e descubra os segredos da magia sagrada</p>
            <div class="cta-buttons">
                <a href="#" class="btn btn-primary" onclick="openModal()">
                    <i class="fas fa-sign-in-alt"></i>
                    Começar Jornada
                </a>
                <a href="#sobre" class="btn btn-secondary">
                    <i class="fas fa-info-circle"></i>
                    Saiba Mais
                </a>
            </div>
        </div>
    </section>

    <!-- Sobre Section -->
    <section id="sobre" class="section">
        <div class="container">
            <h2>Sobre Nós</h2>
            <div class="features">
                <div class="feature-card">
                    <i class="fas fa-users"></i>
                    <h3>3 Grandes Magos</h3>
                    <p>Mestres experientes dedicados a compartilhar conhecimentos sagrados e desmistificar o poder oculto.</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-feather-alt"></i>
                    <h3>Abordagem Leve</h3>
                    <p>Sem amarras dogmáticas ou rituais complexos. Aprendizado natural e progressivo.</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-graduation-cap"></i>
                    <h3>Sistema de Graus</h3>
                    <p>Evolução gradual através de graus: Iniciante, Iniciado, Adepto, Aprendiz, Discípulo, Mago.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Biblioteca Section -->
    <section id="biblioteca" class="section">
        <div class="container">
            <h2>Biblioteca Sagrada</h2>
            <div class="features">
                <div class="feature-card">
                    <i class="fas fa-book"></i>
                    <h3>Tomos de Conhecimento</h3>
                    <p>Material de leitura organizado por assuntos relacionados à magia e desenvolvimento espiritual.</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-lock"></i>
                    <h3>Acesso por Grau</h3>
                    <p>Conteúdo liberado progressivamente conforme sua evolução no sistema.</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-upload"></i>
                    <h3>Upload de Arquivos</h3>
                    <p>Compartilhe e acesse documentos, PDFs e materiais de estudo.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contato Section -->
    <section id="contato" class="section">
        <div class="container">
            <h2>Contato</h2>
            <div style="text-align: center;">
                <div class="feature-card" style="max-width: 500px; margin: 0 auto;">
                    <i class="fas fa-envelope"></i>
                    <h3>Entre em Contato</h3>
                    <p>Para dúvidas, informações ou orientações, entre em contato conosco:</p>
                    <p style="color: #ffd700; font-size: 1.2rem; font-weight: bold;">
                        sms.grandemago@gmail.com
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Login Modal -->
    <div id="loginModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            
            <div class="form-tabs">
                <button class="tab-btn active" onclick="showTab('login')">Entrar</button>
                <button class="tab-btn" onclick="showTab('register')">Registrar</button>
            </div>

            <!-- Login Form -->
            <div id="login" class="tab-content active">
                <form id="loginForm">
                    <div class="form-group">
                        <label for="loginUsername">Usuário:</label>
                        <input type="text" id="loginUsername" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="loginPassword">Senha:</label>
                        <input type="password" id="loginPassword" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-sign-in-alt"></i>
                        Entrar
                    </button>
                </form>
            </div>

            <!-- Register Form -->
            <div id="register" class="tab-content">
                <form id="registerForm">
                    <div class="form-group">
                        <label for="regUsername">Usuário:</label>
                        <input type="text" id="regUsername" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="regEmail">Email:</label>
                        <input type="email" id="regEmail" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="regNomeMagico">Nome Mágico:</label>
                        <input type="text" id="regNomeMagico" name="nome_magico" required>
                    </div>
                    <div class="form-group">
                        <label for="regPassword">Senha:</label>
                        <input type="password" id="regPassword" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-user-plus"></i>
                        Registrar
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Sistema Mágico Sagrado. Todos os direitos reservados.</p>
            <p>Contato: <a href="mailto:sms.grandemago@gmail.com">sms.grandemago@gmail.com</a></p>
        </div>
    </footer>

    <script>
        // Modal functions
        function openModal() {
            document.getElementById('loginModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        function showTab(tabName) {
            // Hide all tab contents
            const tabContents = document.querySelectorAll('.tab-content');
            tabContents.forEach(tab => tab.classList.remove('active'));
            
            // Remove active class from all tab buttons
            const tabBtns = document.querySelectorAll('.tab-btn');
            tabBtns.forEach(btn => btn.classList.remove('active'));
            
            // Show selected tab and mark button as active
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('loginModal');
            if (event.target == modal) {
                closeModal();
            }
        }

        // Login form submission
        document.getElementById('loginForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (response.ok) {
                    alert('Login realizado com sucesso!');
                    window.location.href = '/dashboard';
                } else {
                    alert('Erro: ' + result.error);
                }
            } catch (error) {
                alert('Erro de conexão: ' + error.message);
            }
        });

        // Register form submission
        document.getElementById('registerForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            try {
                const response = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (response.ok) {
                    alert('Registro realizado com sucesso! Faça login para continuar.');
                    showTab('login');
                } else {
                    alert('Erro: ' + result.error);
                }
            } catch (error) {
                alert('Erro de conexão: ' + error.message);
            }
        });
    </script>
</body>
</html>'''

@app.route('/dashboard')
def dashboard():
    return '''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema Mágico Sagrado</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            color: #ffffff;
            min-height: 100vh;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            padding: 2rem 0;
        }

        .sidebar-header {
            padding: 0 1.5rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 2rem;
        }

        .sidebar-header h2 {
            color: #ffd700;
            font-size: 1.2rem;
        }

        .nav-item {
            display: block;
            padding: 1rem 1.5rem;
            color: #ffffff;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .nav-item:hover, .nav-item.active {
            background: rgba(255, 215, 0, 0.1);
            border-left-color: #ffd700;
            color: #ffd700;
        }

        .nav-item i {
            margin-right: 0.5rem;
            width: 20px;
        }

        .main-content {
            flex: 1;
            padding: 2rem;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .header h1 {
            color: #ffd700;
            font-size: 2.5rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1a1a2e;
            font-weight: bold;
        }

        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 25px;
            background: linear-gradient(45deg, #ff6b6b, #ee5a52);
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.3);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 1.5rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(255, 215, 0, 0.2);
        }

        .stat-card h3 {
            color: #ffd700;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .stat-card .value {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        .stat-card .subtitle {
            color: #cccccc;
            font-size: 0.9rem;
        }

        .section {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .section h2 {
            color: #ffd700;
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }

        .admin-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .admin-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
        }

        .admin-card:hover {
            transform: translateY(-3px);
            background: rgba(255, 255, 255, 0.15);
        }

        .admin-card h3 {
            color: #ffed4e;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .admin-btn {
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            color: #1a1a2e;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 25px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
        }

        .admin-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 215, 0, 0.3);
        }

        .hidden {
            display: none;
        }

        @media (max-width: 768px) {
            .dashboard {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                order: 2;
            }
            
            .main-content {
                order: 1;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-magic"></i> Sistema Mágico Sagrado</h2>
            </div>
            <a href="#dashboard" class="nav-item active" onclick="showSection('dashboard')">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="#tarefas" class="nav-item" onclick="showSection('tarefas')">
                <i class="fas fa-tasks"></i> Tarefas Diárias
            </a>
            <a href="#biblioteca" class="nav-item" onclick="showSection('biblioteca')">
                <i class="fas fa-book"></i> Biblioteca
            </a>
            <a href="#mensagens" class="nav-item" onclick="showSection('mensagens')">
                <i class="fas fa-envelope"></i> Mensagens
            </a>
            <a href="#forum" class="nav-item" onclick="showSection('forum')">
                <i class="fas fa-comments"></i> Fórum
            </a>
            <a href="#comprovantes" class="nav-item" onclick="showSection('comprovantes')">
                <i class="fas fa-receipt"></i> Comprovantes
            </a>
            <a href="#progresso" class="nav-item" onclick="showSection('progresso')">
                <i class="fas fa-chart-line"></i> Meu Progresso
            </a>
            <a href="#admin" class="nav-item" id="adminNav" onclick="showSection('admin')">
                <i class="fas fa-cog"></i> Administração
            </a>
        </nav>

        <main class="main-content">
            <div class="header">
                <h1>Dashboard</h1>
                <div class="user-info">
                    <div class="user-avatar" id="userAvatar">G</div>
                    <span id="userName">Grande Mago</span>
                    <button class="btn" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i> Sair
                    </button>
                </div>
            </div>

            <!-- Dashboard Section -->
            <div id="dashboard" class="content-section">
                <div class="stats-grid">
                    <div class="stat-card">
                        <h3><i class="fas fa-star"></i> Pontos de Magia</h3>
                        <div class="value" id="pontos">999</div>
                        <div class="subtitle">Próximo grau em: 90 pontos</div>
                    </div>
                    <div class="stat-card">
                        <h3><i class="fas fa-graduation-cap"></i> Grau Atual</h3>
                        <div class="value" id="grau">Mago</div>
                    </div>
                    <div class="stat-card">
                        <h3><i class="fas fa-tasks"></i> Tarefas Pendentes</h3>
                        <div class="value" id="tarefasPendentes">0</div>
                        <div class="subtitle">tarefas</div>
                    </div>
                    <div class="stat-card">
                        <h3><i class="fas fa-receipt"></i> Comprovantes</h3>
                        <div class="value">
                            <span style="font-size: 1rem;">Pendentes: <span id="comprovantesPendentes">0</span></span><br>
                            <span style="font-size: 1rem;">Aprovados: <span id="comprovantesAprovados">0</span></span>
                        </div>
                    </div>
                </div>

                <!-- Admin Panel -->
                <div class="section" id="adminPanel">
                    <h2>Painel Administrativo</h2>
                    <div class="admin-grid">
                        <div class="admin-card">
                            <h3><i class="fas fa-users"></i> Gerenciar Usuários</h3>
                            <button class="admin-btn" onclick="alert('Funcionalidade em desenvolvimento')">
                                Acessar Gerenciamento
                            </button>
                        </div>
                        <div class="admin-card">
                            <h3><i class="fas fa-tasks"></i> Gerenciar Tarefas</h3>
                            <button class="admin-btn" onclick="alert('Funcionalidade em desenvolvimento')">
                                Nova Tarefa
                            </button>
                        </div>
                        <div class="admin-card">
                            <h3><i class="fas fa-book"></i> Gerenciar Biblioteca</h3>
                            <button class="admin-btn" onclick="alert('Funcionalidade em desenvolvimento')">
                                Novo Item
                            </button>
                        </div>
                        <div class="admin-card">
                            <h3><i class="fas fa-chart-bar"></i> Relatórios</h3>
                            <button class="admin-btn" onclick="alert('Funcionalidade em desenvolvimento')">
                                Ver Relatórios
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Other sections would go here -->
            <div id="tarefas" class="content-section hidden">
                <div class="section">
                    <h2>Tarefas Diárias</h2>
                    <p>Carregando tarefas...</p>
                </div>
            </div>

            <div id="biblioteca" class="content-section hidden">
                <div class="section">
                    <h2>Biblioteca Sagrada</h2>
                    <p>Nenhum item disponível na biblioteca.</p>
                </div>
            </div>

            <div id="mensagens" class="content-section hidden">
                <div class="section">
                    <h2>Mensagens</h2>
                    <h3>Mensagens do Mentor</h3>
                    <h3>Notificações</h3>
                    <p>0 novas notificações</p>
                    <p>Carregando mensagens...</p>
                </div>
            </div>

            <div id="forum" class="content-section hidden">
                <div class="section">
                    <h2>Fórum de Discussão</h2>
                    <p>Carregando fórum...</p>
                </div>
            </div>

            <div id="comprovantes" class="content-section hidden">
                <div class="section">
                    <h2>Comprovantes de Pagamento</h2>
                    <p>Nenhum comprovante enviado ainda.</p>
                </div>
            </div>

            <div id="progresso" class="content-section hidden">
                <div class="section">
                    <h2>Meu Progresso</h2>
                    <h3>Conquistas</h3>
                    <p>0 conquistas desbloqueadas</p>
                    <h3>Tarefas Concluídas</h3>
                    <p>0 tarefas concluídas</p>
                </div>
            </div>

            <div id="admin" class="content-section hidden">
                <div class="section">
                    <h2>Administração</h2>
                    <div class="admin-grid">
                        <div class="admin-card">
                            <h3><i class="fas fa-users"></i> Gerenciar Usuários</h3>
                            <button class="admin-btn" onclick="alert('Funcionalidade em desenvolvimento')">
                                Acessar Gerenciamento
                            </button>
                        </div>
                        <div class="admin-card">
                            <h3><i class="fas fa-tasks"></i> Gerenciar Tarefas</h3>
                            <button class="admin-btn" onclick="alert('Funcionalidade em desenvolvimento')">
                                Nova Tarefa
                            </button>
                        </div>
                        <div class="admin-card">
                            <h3><i class="fas fa-book"></i> Gerenciar Biblioteca</h3>
                            <button class="admin-btn" onclick="alert('Funcionalidade em desenvolvimento')">
                                Novo Item
                            </button>
                        </div>
                        <div class="admin-card">
                            <h3><i class="fas fa-chart-bar"></i> Relatórios</h3>
                            <button class="admin-btn" onclick="alert('Funcionalidade em desenvolvimento')">
                                Ver Relatórios
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        let currentUser = null;

        // Check authentication on page load
        document.addEventListener('DOMContentLoaded', async function() {
            try {
                const response = await fetch('/api/auth/check');
                if (!response.ok) {
                    window.location.href = '/';
                    return;
                }
                
                const userData = await response.json();
                currentUser = userData.user;
                
                // Update UI with user data
                document.getElementById('userName').textContent = currentUser.nome_magico;
                document.getElementById('userAvatar').textContent = currentUser.nome_magico.charAt(0).toUpperCase();
                document.getElementById('pontos').textContent = currentUser.pontos || 0;
                document.getElementById('grau').textContent = currentUser.grau || 'Iniciante';
                
                // Show/hide admin panel based on user role
                if (!currentUser.is_admin && !currentUser.is_gm) {
                    document.getElementById('adminPanel').style.display = 'none';
                    document.getElementById('adminNav').style.display = 'none';
                }
                
                // Load additional data
                loadUserStats();
                
            } catch (error) {
                console.error('Error checking authentication:', error);
                window.location.href = '/';
            }
        });

        async function loadUserStats() {
            try {
                // Load comprovantes stats
                const comprovantesResponse = await fetch('/api/comprovante/estatisticas');
                if (comprovantesResponse.ok) {
                    const stats = await comprovantesResponse.json();
                    document.getElementById('comprovantesPendentes').textContent = stats.pendentes || 0;
                    document.getElementById('comprovantesAprovados').textContent = stats.aprovados || 0;
                }
            } catch (error) {
                console.error('Error loading stats:', error);
            }
        }

        function showSection(sectionName) {
            // Hide all sections
            const sections = document.querySelectorAll('.content-section');
            sections.forEach(section => section.classList.add('hidden'));
            
            // Remove active class from all nav items
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(item => item.classList.remove('active'));
            
            // Show selected section
            document.getElementById(sectionName).classList.remove('hidden');
            
            // Add active class to clicked nav item
            event.target.classList.add('active');
        }

        async function logout() {
            try {
                await fetch('/api/auth/logout', { method: 'POST' });
                window.location.href = '/';
            } catch (error) {
                console.error('Error logging out:', error);
                window.location.href = '/';
            }
        }
    </script>
</body>
</html>'''

# Create database tables and admin user
def create_admin_user():
    """Create default admin user if it doesn't exist"""
    admin = User.query.filter_by(username='grandemago').first()
    if not admin:
        from werkzeug.security import generate_password_hash
        admin = User(
            username='grandemago',
            email='admin@sistemamagicosagrado.com',
            nome_magico='Grande Mago',
            password_hash=generate_password_hash('mago123'),
            is_admin=True,
            is_gm=True,
            grau='Mago',
            pontos=999
        )
        db.session.add(admin)
        db.session.commit()
        print("Admin user created: grandemago / mago123")

if __name__ == '__main__':
    with app.app_context():
        # Create all database tables
        db.create_all()
        
        # Create admin user
        create_admin_user()
        
        print("Database initialized successfully!")
        print("Admin credentials: grandemago / mago123")
        print("Starting server on http://0.0.0.0:5000")
    
    app.run(host='0.0.0.0', port=5000, debug=True)

