from flask import Blueprint, request, jsonify, session, current_app
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from user import db, User
import os
import uuid
from werkzeug.utils import secure_filename

biblioteca_bp = Blueprint('biblioteca', __name__)

class BibliotecaItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(200), nullable=False)
    descricao = db.Column(db.Text, nullable=True)
    tipo = db.Column(db.String(20), nullable=False)  # 'texto', 'arquivo'
    conteudo = db.Column(db.Text, nullable=True)  # Para textos
    arquivo_path = db.Column(db.String(500), nullable=True)  # Para arquivos
    arquivo_nome = db.Column(db.String(200), nullable=True)  # Nome original do arquivo
    grau_minimo = db.Column(db.String(20), default='Iniciante', nullable=False)
    criado_por = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)
    ativo = db.Column(db.Boolean, default=True, nullable=False)
    
    # Relacionamento com o criador
    criador = db.relationship('User', backref='biblioteca_items')

    def to_dict(self):
        return {
            'id': self.id,
            'titulo': self.titulo,
            'descricao': self.descricao,
            'tipo': self.tipo,
            'conteudo': self.conteudo,
            'arquivo_path': self.arquivo_path,
            'arquivo_nome': self.arquivo_nome,
            'grau_minimo': self.grau_minimo,
            'criado_por': self.criado_por,
            'criador_nome': self.criador.nome_magico if self.criador else 'Sistema',
            'data_criacao': self.data_criacao.isoformat() if self.data_criacao else None,
            'ativo': self.ativo
        }

def require_auth():
    """Verificar se o usuário está autenticado"""
    if 'user_id' not in session:
        return jsonify({'error': 'Não autenticado'}), 401
    return None

def require_gm():
    """Verificar se o usuário é G.M. ou admin"""
    if 'user_id' not in session:
        return jsonify({'error': 'Não autenticado'}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not (user.is_gm or user.is_admin):
        return jsonify({'error': 'Acesso negado'}), 403
    
    return None

def allowed_file(filename):
    """Verificar se o arquivo é permitido"""
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'txt', 'jpg', 'jpeg', 'png', 'gif', 'mp3', 'mp4', 'avi'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@biblioteca_bp.route('/items', methods=['GET'])
def get_biblioteca_items():
    """Listar itens da biblioteca baseado no grau do usuário"""
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    try:
        user = User.query.get(session['user_id'])
        
        # Hierarquia de graus
        graus_hierarquia = ['Iniciante', 'Iniciado', 'Adepto', 'Aprendiz', 'Discípulo', 'Mago']
        grau_index = graus_hierarquia.index(user.grau) if user.grau in graus_hierarquia else 0
        graus_permitidos = graus_hierarquia[:grau_index + 1]
        
        items = BibliotecaItem.query.filter(
            BibliotecaItem.ativo == True,
            BibliotecaItem.grau_minimo.in_(graus_permitidos)
        ).order_by(BibliotecaItem.data_criacao.desc()).all()
        
        return jsonify({
            'items': [item.to_dict() for item in items],
            'grau_usuario': user.grau
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@biblioteca_bp.route('/items', methods=['POST'])
def create_biblioteca_item():
    """Criar novo item na biblioteca (texto ou arquivo)"""
    auth_check = require_gm()
    if auth_check:
        return auth_check
    
    try:
        # Verificar se é upload de arquivo ou texto
        if 'arquivo' in request.files:
            # Upload de arquivo
            arquivo = request.files['arquivo']
            if arquivo.filename == '':
                return jsonify({'error': 'Nenhum arquivo selecionado'}), 400
            
            if arquivo and allowed_file(arquivo.filename):
                # Gerar nome único para o arquivo
                filename = secure_filename(arquivo.filename)
                unique_filename = f"{uuid.uuid4()}_{filename}"
                
                # Salvar arquivo
                upload_folder = current_app.config['UPLOAD_FOLDER']
                biblioteca_folder = os.path.join(upload_folder, 'biblioteca')
                os.makedirs(biblioteca_folder, exist_ok=True)
                
                arquivo_path = os.path.join(biblioteca_folder, unique_filename)
                arquivo.save(arquivo_path)
                
                # Criar item na biblioteca
                item = BibliotecaItem(
                    titulo=request.form.get('titulo'),
                    descricao=request.form.get('descricao'),
                    tipo='arquivo',
                    arquivo_path=arquivo_path,
                    arquivo_nome=filename,
                    grau_minimo=request.form.get('grau_minimo', 'Iniciante'),
                    criado_por=session['user_id']
                )
            else:
                return jsonify({'error': 'Tipo de arquivo não permitido'}), 400
        else:
            # Texto
            data = request.get_json()
            if not data or not data.get('titulo') or not data.get('conteudo'):
                return jsonify({'error': 'Título e conteúdo são obrigatórios'}), 400
            
            item = BibliotecaItem(
                titulo=data.get('titulo'),
                descricao=data.get('descricao'),
                tipo='texto',
                conteudo=data.get('conteudo'),
                grau_minimo=data.get('grau_minimo', 'Iniciante'),
                criado_por=session['user_id']
            )
        
        db.session.add(item)
        db.session.commit()
        
        return jsonify({
            'message': 'Item criado com sucesso',
            'item': item.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@biblioteca_bp.route('/items/<int:item_id>', methods=['GET'])
def get_biblioteca_item(item_id):
    """Obter detalhes de um item específico"""
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    try:
        user = User.query.get(session['user_id'])
        item = BibliotecaItem.query.filter_by(id=item_id, ativo=True).first_or_404()
        
        # Verificar se o usuário tem acesso ao item
        graus_hierarquia = ['Iniciante', 'Iniciado', 'Adepto', 'Aprendiz', 'Discípulo', 'Mago']
        grau_user_index = graus_hierarquia.index(user.grau) if user.grau in graus_hierarquia else 0
        grau_item_index = graus_hierarquia.index(item.grau_minimo) if item.grau_minimo in graus_hierarquia else 0
        
        if grau_user_index < grau_item_index:
            return jsonify({'error': 'Grau insuficiente para acessar este item'}), 403
        
        return jsonify({'item': item.to_dict()}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@biblioteca_bp.route('/items/<int:item_id>/download', methods=['GET'])
def download_arquivo(item_id):
    """Download de arquivo da biblioteca"""
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    try:
        user = User.query.get(session['user_id'])
        item = BibliotecaItem.query.filter_by(id=item_id, ativo=True, tipo='arquivo').first_or_404()
        
        # Verificar acesso
        graus_hierarquia = ['Iniciante', 'Iniciado', 'Adepto', 'Aprendiz', 'Discípulo', 'Mago']
        grau_user_index = graus_hierarquia.index(user.grau) if user.grau in graus_hierarquia else 0
        grau_item_index = graus_hierarquia.index(item.grau_minimo) if item.grau_minimo in graus_hierarquia else 0
        
        if grau_user_index < grau_item_index:
            return jsonify({'error': 'Grau insuficiente para acessar este arquivo'}), 403
        
        if not os.path.exists(item.arquivo_path):
            return jsonify({'error': 'Arquivo não encontrado'}), 404
        
        from flask import send_file
        return send_file(item.arquivo_path, as_attachment=True, download_name=item.arquivo_nome)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@biblioteca_bp.route('/items/<int:item_id>', methods=['PUT'])
def update_biblioteca_item(item_id):
    """Atualizar item da biblioteca"""
    auth_check = require_gm()
    if auth_check:
        return auth_check
    
    try:
        item = BibliotecaItem.query.get_or_404(item_id)
        data = request.get_json()
        
        if data.get('titulo'):
            item.titulo = data.get('titulo')
        if data.get('descricao'):
            item.descricao = data.get('descricao')
        if data.get('conteudo') and item.tipo == 'texto':
            item.conteudo = data.get('conteudo')
        if data.get('grau_minimo'):
            item.grau_minimo = data.get('grau_minimo')
        
        db.session.commit()
        
        return jsonify({
            'message': 'Item atualizado com sucesso',
            'item': item.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@biblioteca_bp.route('/items/<int:item_id>', methods=['DELETE'])
def delete_biblioteca_item(item_id):
    """Remover item da biblioteca (soft delete)"""
    auth_check = require_gm()
    if auth_check:
        return auth_check
    
    try:
        item = BibliotecaItem.query.get_or_404(item_id)
        item.ativo = False
        db.session.commit()
        
        return jsonify({'message': 'Item removido com sucesso'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Rotas administrativas
@biblioteca_bp.route('/admin/items', methods=['GET'])
def admin_get_all_items():
    """Listar todos os itens (incluindo inativos) para administradores"""
    auth_check = require_gm()
    if auth_check:
        return auth_check
    
    try:
        items = BibliotecaItem.query.order_by(BibliotecaItem.data_criacao.desc()).all()
        return jsonify({'items': [item.to_dict() for item in items]}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@biblioteca_bp.route('/admin/items/<int:item_id>/restore', methods=['POST'])
def admin_restore_item(item_id):
    """Restaurar item removido (apenas admin)"""
    auth_check = require_gm()
    if auth_check:
        return auth_check
    
    try:
        item = BibliotecaItem.query.get_or_404(item_id)
        item.ativo = True
        db.session.commit()
        
        return jsonify({'message': 'Item restaurado com sucesso'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

