from main import app, db, create_admin_user

with app.app_context():
    db.create_all()
    create_admin_user()
    print("Database initialized and admin user created.")

