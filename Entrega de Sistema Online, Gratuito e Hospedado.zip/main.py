import os
from flask import Flask, render_template, send_from_directory
from flask_cors import CORS

# Import models and blueprints
from user import db, User
from tarefa import Tarefa
from tarefa_execucao import TarefaExecucao
from biblioteca import BibliotecaItem
from mensagem import Mensagem
from forum import ForumPost
from comprovante_pagamento import ComprovantePagamento

# Import blueprints
from auth import auth_bp
from admin import admin_bp
from user import user_bp
from biblioteca import biblioteca_bp
from mensagem import mensagem_bp
from forum import forum_bp
from comprovante_pagamento import comprovante_bp

app = Flask(__name__, static_folder='static', static_url_path='')

# Configuration
app.config['SECRET_KEY'] = 'sua_chave_secreta_muito_segura_aqui_2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('database', exist_ok=True)

# Initialize extensions
db.init_app(app)
CORS(app, supports_credentials=True)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(admin_bp, url_prefix='/api/admin')
app.register_blueprint(user_bp, url_prefix='/api/user')
app.register_blueprint(biblioteca_bp, url_prefix='/api/biblioteca')
app.register_blueprint(mensagem_bp, url_prefix='/api/mensagens')
app.register_blueprint(forum_bp, url_prefix='/api/forum')
app.register_blueprint(comprovante_bp, url_prefix='/api/comprovante')

# Routes for serving static files
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/dashboard.html')
def dashboard():
    return send_from_directory('static', 'dashboard.html')

@app.route('/sobre.html')
def sobre():
    return send_from_directory('static', 'sobre.html')

@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

# Create database tables and admin user
def create_admin_user():
    """Create default admin user if it doesn't exist"""
    admin = User.query.filter_by(username='grandemago').first()
    if not admin:
        from werkzeug.security import generate_password_hash
        admin = User(
            username='grandemago',
            email='admin@sistemamagicosagrado.com',
            nome_magico='Grande Mago',
            password_hash=generate_password_hash('mago123'),
            is_admin=True,
            is_gm=True,
            grau='Mago',
            pontos=999
        )
        db.session.add(admin)
        db.session.commit()
        print("Admin user created: grandemago / mago123")

if __name__ == '__main__':
    with app.app_context():
        # Create all database tables
        db.create_all()
        
        # Create admin user
        create_admin_user()
        
        print("Database initialized successfully!")
        print("Admin credentials: grandemago / mago123")
        print("Starting server on http://0.0.0.0:5000")
    
    app.run(host='0.0.0.0', port=5000, debug=True)

